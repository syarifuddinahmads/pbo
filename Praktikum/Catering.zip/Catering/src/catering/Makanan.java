/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package catering;

/**
 *
 * @author udin
 */
public class Makanan {
    int idMakanan;
    String namaMakanan;
    double hargaMakanan;

    public Makanan(int idMakanan, String namaMakanan, double hargaMakanan) {
        this.idMakanan = idMakanan;
        this.namaMakanan = namaMakanan;
        this.hargaMakanan = hargaMakanan;
    }

    public int getIdMakanan() {
        return idMakanan;
    }

    public String getNamaMakanan() {
        return namaMakanan;
    }

    public double getHargaMakanan() {
        return hargaMakanan;
    }
    
    public void detailMakanan(){
        System.out.println("Id : "+getIdMakanan()+"\nNama : "+getNamaMakanan()+"\nHarga : "+getHargaMakanan());
    }
}
