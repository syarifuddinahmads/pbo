/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package catering;

import java.util.Scanner;

/**
 *
 * @author udin
 */
public class MakananProses extends abstractProses{
 
    Scanner scanner = new Scanner(System.in);
    
    @Override
    public void insert(){
        System.out.print("Nama : ");
        String nama = scanner.next();
        System.out.print("Harga : ");
        double hargaMakanan = scanner.nextDouble();
        Makanan makanan = new  Makanan((DataCatering.makananArr.size()+1), nama, hargaMakanan);
        DataCatering.makananArr.add(makanan);
        
    }
    
    @Override
    public void view(){
        System.out.println("--- Data Makanan ---");
        for (int i = 0; i < DataCatering.makananArr.size(); i++) {
            DataCatering.makananArr.get(i).detailMakanan();
        }
    }
    
    @Override
    public void edit(){
        
    }
    
    @Override
    public void delete(){
        System.out.println("--- Delete Makanan ---");
        System.out.print("Input Id makanan : ");
        int idMakanan = scanner.nextInt();
        for (int i = 0; i < DataCatering.makananArr.size(); i++) {
            if(DataCatering.makananArr.get(i).getIdMakanan() == idMakanan){
                DataCatering.makananArr.remove(i);
            }
        }
    }
    
}
