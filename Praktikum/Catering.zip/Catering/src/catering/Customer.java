/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package catering;

/**
 *
 * @author udin
 */
public class Customer  extends User{
    
    int idCustomer;

    public Customer(int idCustomer, String nama, String username, String password, String alamat, String noTelp) {
        super(nama, username, password, alamat, noTelp);
        this.idCustomer = idCustomer;
    }

    public int getIdCustomer() {
        return idCustomer;
    }
    
}
