/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package catering;

import java.util.Scanner;

/**
 *
 * @author udin
 */
public class Catering {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PegawaiProses pegawaiProses = new PegawaiProses();
        MakananProses makananProses = new MakananProses();
        PesananProses pesananProses = new PesananProses();

        do {

            System.out.println("--- Login ---");
            System.out.print("Username : ");
            String username = scanner.next();
            System.out.print("Password : ");
            String password = scanner.next();

            if (username.equals("admin") && password.equals("admin")) {
                menuUtama:
                do {
                    System.out.println("--- Menu Catering ---");
                    System.out.println("1.Pegawai\n2.Makanan\n3.Pesanan\n0.Selesai");
                    System.out.print("Masukkan Manu : ");
                    int menuCatering = scanner.nextInt();
                    switch (menuCatering) {
                        case 1:
                            System.out.println("--- Menu Pegawai ---");
                            do {
                                System.out.println("1.Input Pegawai\n2.View Pegawai\n3.Update Pegawai\n4.Delete Pegawai\n5.Kembali Ke Menu");
                                int menuPegawai = scanner.nextInt();
                                switch (menuPegawai) {
                                    case 1:
                                        pegawaiProses.insert();
                                        break;
                                    case 2:
                                        pegawaiProses.view();
                                        break;
                                    case 3:
                                        pegawaiProses.edit();
                                        break;
                                    case 4:
                                        pegawaiProses.delete();
                                        break;
                                    case 5:
                                        continue menuUtama;
                                }
                            } while (true);
                        case 2:
                            do {
                                System.out.println("--- Menu Makanan ---");
                                System.out.println("1.Input Makanan\n2.View Makanan\n3.Update Makanan\n4.Delete Makanan\n5.Kembali Ke Menu");
                                int menuMakanan = scanner.nextInt();
                                switch (menuMakanan) {
                                    case 1:
                                        makananProses.insert();
                                        break;
                                    case 2:
                                        makananProses.view();
                                        break;
                                    case 3:
                                        makananProses.edit();
                                        break;
                                    case 4:
                                        makananProses.delete();
                                        break;
                                    case 5:
                                        continue menuUtama;
                                }
                            } while (true);
                        case 3:
                            do {
                                System.out.println("--- Menu Pesanan ---");
                                System.out.println("1.Input Pesanan\n2.View Pesanan\n3.Update Pesanan\n4.Delete Pesanan\n5.Kembali Ke Menu");
                                int menuMakanan = scanner.nextInt();
                                switch (menuMakanan) {
                                    case 1:
                                        pesananProses.insert();
                                        break;
                                    case 2:
                                        pesananProses.view();
                                        break;
                                    case 3:
                                        pesananProses.edit();
                                        break;
                                    case 4:
                                        pesananProses.delete();
                                        break;
                                    case 5:
                                        continue menuUtama;
                                }
                            } while (true);
                    }
                } while (true);
            }

        } while (true);

    }

}
