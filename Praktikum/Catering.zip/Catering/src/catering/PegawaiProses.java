/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package catering;

import java.util.Scanner;

/**
 *
 * @author udin
 */
public class PegawaiProses extends abstractProses{
    
    Scanner scanner = new Scanner(System.in);
    
    @Override
    public void insert(){
        System.out.print("Nama : ");
        String nama = scanner.next();
        System.out.print("Username : ");
        String username = scanner.next();
        System.out.print("Password : ");
        String password = scanner.next();
        System.out.print("Alamat : ");
        String alamat = scanner.next();
        System.out.print("No Telepon : ");
        String noTelp = scanner.next();
        Pegawai pegawai = new  Pegawai((DataCatering.pegawaiArr.size()+1), nama, username, password, alamat, noTelp);
        DataCatering.pegawaiArr.add(pegawai);
        
    }
    
    @Override
    public void view(){
        System.out.println("--- Data Pegawai ---");
        for (int i = 0; i < DataCatering.pegawaiArr.size(); i++) {
            DataCatering.pegawaiArr.get(i).detailPegawai();
        }
    }
    
    @Override
    public void edit(){
        
    }
    
    @Override
    public void delete(){
        System.out.println("--- Delete Pegawai ---");
        System.out.print("Input Id pegawai : ");
        int idPegawai = scanner.nextInt();
        for (int i = 0; i < DataCatering.pegawaiArr.size(); i++) {
            if(DataCatering.pegawaiArr.get(i).getIdPegawai() == idPegawai){
                DataCatering.pegawaiArr.remove(i);
            }
        }
    }
}
