/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package catering;

/**
 *
 * @author udin
 */
public class Pegawai extends User{
    int idPegawai;

    public Pegawai(int idPegawai, String nama, String username, String password, String alamat, String noTelp) {
        super(nama, username, password, alamat, noTelp);
        this.idPegawai = idPegawai;
    }

    public int getIdPegawai() {
        return idPegawai;
    }
    
    public void detailPegawai(){
        System.out.println("Id : "+getIdPegawai()+"\nNama : "+super.getNama()+"\nAlamat : "+super.getAlamat()+"\nNo Telp : "+super.getNoTelp());
    }
    
    
    
}
