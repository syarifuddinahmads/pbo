/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package catering;

/**
 *
 * @author udin
 */
public abstract class abstractProses {
    
    public void insert(){
        
    }
    
    public void view(){
        
    }
    
    public void edit(){
        
    }
    
    public void delete(){
        
    }
    
}
