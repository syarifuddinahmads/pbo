/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package catering;

import java.util.ArrayList;

/**
 *
 * @author udin
 */
public class DataCatering {
    public static ArrayList<Pegawai> pegawaiArr = new ArrayList<>();
    public static ArrayList<Customer> customerArr = new ArrayList<>();
    public static ArrayList<Pesanan> pesananArr = new ArrayList<>();
    public static ArrayList<Makanan> makananArr = new ArrayList<>();
}
