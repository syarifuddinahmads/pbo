/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package catering;

/**
 *
 * @author udin
 */
public class Pesanan {
    int idPesanan;
    Pegawai pegawai;
    Customer customer;
    Makanan[] makanan;

    public Pesanan(int idPesanan, Pegawai pegawai, Customer customer, Makanan[] makanan) {
        this.idPesanan = idPesanan;
        this.pegawai = pegawai;
        this.customer = customer;
        this.makanan = makanan;
    }

    public int getIdPesanan() {
        return idPesanan;
    }

    public Pegawai getPegawai() {
        return pegawai;
    }

    public Customer getCustomer() {
        return customer;
    }

    public Makanan[] getMakanan() {
        return makanan;
    }

       
    
    
}
