/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modul6kamus;

import javax.swing.text.Keymap;
import modul6kamus.view.KamusView;
import sun.security.krb5.internal.KDCOptions;

/**
 *
 * @author praktikan
 */
public class Modul6Kamus {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        KamusView kamusView = new KamusView();
    }
    
}
