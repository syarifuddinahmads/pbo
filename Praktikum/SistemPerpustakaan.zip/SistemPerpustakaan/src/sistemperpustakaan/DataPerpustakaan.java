/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemperpustakaan;

import java.util.ArrayList;
import sistemperpustakaan.model.Buku;
import sistemperpustakaan.model.Peminjam;
import sistemperpustakaan.model.User;

/**
 *
 * @author udin
 */
public class DataPerpustakaan {
    
    public static ArrayList<Buku> BukuArr = new ArrayList<>();
    public static ArrayList<User> UserArr = new ArrayList<>();
    public static ArrayList<Peminjam> PeminjamArr = new ArrayList<>();
    
}
