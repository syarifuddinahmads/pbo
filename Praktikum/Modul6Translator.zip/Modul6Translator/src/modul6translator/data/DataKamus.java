/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modul6translator.data;

import java.util.ArrayList;
import modul6translator.model.KamusModel;

/**
 *
 * @author udin
 */
public class DataKamus {

    public static ArrayList<KamusModel> dataKamusArr = new ArrayList<>();
}
