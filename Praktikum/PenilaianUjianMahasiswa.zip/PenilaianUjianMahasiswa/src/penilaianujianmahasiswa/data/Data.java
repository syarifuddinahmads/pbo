/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package penilaianujianmahasiswa.data;

import penilaianujianmahasiswa.model.Nilai;

/**
 *
 * @author udin
 */
public class Data {
    
    public static Nilai[] nilaiArr = new Nilai[100];
    public static int indexNilai = 0;
    
}
